import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/Sidebar.css';

const Sidebar = ({ role }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  const getDashboardPath = () => {
    if (role === 'admin') return '/admin';
    if (role === 'manager') return '/manager';
    return '/employee'; // default is employee
  };

  return (
    <div className="sidebar">
      <h2 className="sidebar-title">Leave System</h2>
      <nav className="sidebar-nav">
        <ul>
          <li><Link to={getDashboardPath()}>Dashboard</Link></li>

          {role === 'employee' && (
            <>
              <li><Link to="/apply-leave">Apply Leave</Link></li>
              <li><Link to="/leave-history">Leave History</Link></li>
            </>
          )}

          {role === 'manager' && (
            <li><Link to="/manager">Manage Leaves</Link></li>
          )}

          {role === 'admin' && (
            <>
              <li><Link to="/admin">Admin Panel</Link></li>
              <li><Link to="/all-employees">All Employees</Link></li>
            </>
          )}

          <li><button onClick={handleLogout} className="logout-btn">Logout</button></li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;
